import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { SignInForm } from "../SignInForm";
import { SignOutButton } from "../SignOutButton";
import { useState } from "react";

interface HeaderProps {
  currentSection: string;
  showSection: (section: string) => void;
  mobileNavOpen: boolean;
  setMobileNavOpen: (open: boolean) => void;
}

export default function Header({ currentSection, showSection, mobileNavOpen, setMobileNavOpen }: HeaderProps) {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [accountDropdownOpen, setAccountDropdownOpen] = useState(false);
  
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const cartCount = useQuery(api.cart.getCount) || 0;

  const toggleMobileNav = () => {
    setMobileNavOpen(!mobileNavOpen);
  };

  return (
    <>
      {/* Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold">Welcome to OneNest</h3>
              <button 
                onClick={() => setShowLoginModal(false)}
                className="text-gray-500 hover:text-gray-700 text-2xl"
              >
                ×
              </button>
            </div>
            <SignInForm />
          </div>
        </div>
      )}

      <header className="sticky top-0 z-40 bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div 
              className="flex items-center cursor-pointer"
              onClick={() => showSection('home')}
            >
              <div className="text-orange-500 text-2xl mr-2">🕊️</div>
              <h1 className="text-2xl font-bold text-gray-900">OneNest</h1>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => showSection('home')}
                className={`text-gray-700 hover:text-orange-500 font-medium ${
                  currentSection === 'home' ? 'text-orange-500' : ''
                }`}
              >
                Home
              </button>
              <button
                onClick={() => showSection('services')}
                className={`text-gray-700 hover:text-orange-500 font-medium ${
                  currentSection === 'services' ? 'text-orange-500' : ''
                }`}
              >
                Services
              </button>
              
              {/* Cart */}
              <button
                onClick={() => showSection('cart')}
                className="relative text-gray-700 hover:text-orange-500"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.5 6M7 13l-1.5 6m0 0h9" />
                </svg>
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Auth Section */}
              <Authenticated>
                <div className="relative">
                  <button
                    onClick={() => setAccountDropdownOpen(!accountDropdownOpen)}
                    className="flex items-center space-x-2 text-gray-700 hover:text-orange-500"
                  >
                    <img
                      src={`https://ui-avatars.com/api/?name=${encodeURIComponent(loggedInUser?.name || loggedInUser?.email || 'User')}&background=ff9900&color=fff`}
                      alt="Profile"
                      className="w-8 h-8 rounded-full"
                    />
                    <span className="font-medium">{loggedInUser?.name || 'My Account'}</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>

                  {accountDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                      <div className="px-4 py-2 border-b">
                        <div className="font-medium text-gray-900">{loggedInUser?.name || 'User'}</div>
                        <div className="text-sm text-gray-500">{loggedInUser?.email}</div>
                      </div>
                      <button
                        onClick={() => {
                          showSection('cloud');
                          setAccountDropdownOpen(false);
                        }}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        <span className="mr-2">☁️</span>
                        Cloud Account
                      </button>
                      <button
                        onClick={() => {
                          showSection('delivery');
                          setAccountDropdownOpen(false);
                        }}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        <span className="mr-2">🚚</span>
                        Delivery Agent
                      </button>
                      <button
                        onClick={() => {
                          showSection('orders');
                          setAccountDropdownOpen(false);
                        }}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        <span className="mr-2">📦</span>
                        My Orders
                      </button>
                      <div className="border-t">
                        <div className="px-4 py-2">
                          <SignOutButton />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </Authenticated>

              <Unauthenticated>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => setShowLoginModal(true)}
                    className="text-gray-700 hover:text-orange-500 font-medium"
                  >
                    Login
                  </button>
                  <button
                    onClick={() => setShowLoginModal(true)}
                    className="bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 font-medium"
                  >
                    Sign Up
                  </button>
                </div>
              </Unauthenticated>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={toggleMobileNav}
                className="text-gray-700 hover:text-orange-500"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileNavOpen && (
            <div className="md:hidden border-t bg-white">
              <div className="px-2 pt-2 pb-3 space-y-1">
                <button
                  onClick={() => showSection('home')}
                  className="block w-full text-left px-3 py-2 text-gray-700 hover:text-orange-500 font-medium"
                >
                  Home
                </button>
                <button
                  onClick={() => showSection('services')}
                  className="block w-full text-left px-3 py-2 text-gray-700 hover:text-orange-500 font-medium"
                >
                  Services
                </button>
                <button
                  onClick={() => showSection('cart')}
                  className="flex items-center px-3 py-2 text-gray-700 hover:text-orange-500 font-medium"
                >
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.5 6M7 13l-1.5 6m0 0h9" />
                  </svg>
                  Cart ({cartCount})
                </button>

                <Authenticated>
                  <button
                    onClick={() => showSection('cloud')}
                    className="block w-full text-left px-3 py-2 text-gray-700 hover:text-orange-500 font-medium"
                  >
                    Cloud Account
                  </button>
                  <button
                    onClick={() => showSection('delivery')}
                    className="block w-full text-left px-3 py-2 text-gray-700 hover:text-orange-500 font-medium"
                  >
                    Delivery Agent
                  </button>
                  <button
                    onClick={() => showSection('orders')}
                    className="block w-full text-left px-3 py-2 text-gray-700 hover:text-orange-500 font-medium"
                  >
                    My Orders
                  </button>
                  <div className="px-3 py-2">
                    <SignOutButton />
                  </div>
                </Authenticated>

                <Unauthenticated>
                  <div className="px-3 py-2 space-y-2">
                    <button
                      onClick={() => setShowLoginModal(true)}
                      className="block w-full text-center bg-gray-100 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-200 font-medium"
                    >
                      Login
                    </button>
                    <button
                      onClick={() => setShowLoginModal(true)}
                      className="block w-full text-center bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 font-medium"
                    >
                      Sign Up
                    </button>
                  </div>
                </Unauthenticated>
              </div>
            </div>
          )}
        </div>
      </header>
    </>
  );
}
