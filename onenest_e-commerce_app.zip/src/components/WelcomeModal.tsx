interface WelcomeModalProps {
  onClose: () => void;
  onSkip: () => void;
}

export default function WelcomeModal({ onClose, onSkip }: WelcomeModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-md mx-4 text-center">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900">Welcome to OneNest</h3>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-3xl font-light"
          >
            ×
          </button>
        </div>
        
        <div className="mb-6">
          <div className="text-6xl mb-4">🕊️</div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">India's Unified SuperApp</h2>
          <p className="text-gray-600">All your daily needs in one place - food, shopping, travel, payments and more.</p>
        </div>
        
        <div className="space-y-3">
          <button
            onClick={onSkip}
            className="w-full bg-orange-500 text-white py-3 rounded-md font-semibold hover:bg-orange-600 transition-colors duration-200"
          >
            Get Started
          </button>
          <button
            onClick={onSkip}
            className="w-full text-gray-600 hover:text-gray-800 py-2 font-medium"
          >
            Skip for now
          </button>
        </div>
      </div>
    </div>
  );
}
