import { useState } from "react";
import { toast } from "sonner";

export default function DeliveryAgent() {
  const [credentials, setCredentials] = useState({
    mobile: "",
    password: ""
  });

  const handleLogin = () => {
    if (!credentials.mobile || !credentials.password) {
      toast.error("Please fill in all fields");
      return;
    }
    toast.success("Delivery agent login successful!");
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Delivery Agent Portal</h2>
      
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="max-w-md mx-auto mb-8">
          <div className="space-y-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i className="fas fa-mobile-alt text-gray-400"></i>
              </div>
              <input
                type="tel"
                placeholder="Mobile Number"
                value={credentials.mobile}
                onChange={(e) => setCredentials(prev => ({ ...prev, mobile: e.target.value }))}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
            
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i className="fas fa-lock text-gray-400"></i>
              </div>
              <input
                type="password"
                placeholder="Password"
                value={credentials.password}
                onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
            
            <button
              onClick={handleLogin}
              className="w-full bg-orange-500 text-white py-3 rounded-md font-semibold hover:bg-orange-600 transition-colors duration-200"
            >
              Login as Delivery Agent
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-lg text-center">
            <div className="text-4xl mb-4">🚚</div>
            <div className="text-2xl font-bold text-gray-900 mb-2">1,248</div>
            <div className="text-gray-600">Total Orders Delivered</div>
          </div>
          
          <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-lg text-center">
            <div className="text-4xl mb-4">💰</div>
            <div className="text-2xl font-bold text-gray-900 mb-2">₹42,850</div>
            <div className="text-gray-600">Total Earnings</div>
          </div>
          
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg text-center">
            <div className="text-4xl mb-4">⭐</div>
            <div className="text-2xl font-bold text-gray-900 mb-2">4.8</div>
            <div className="text-gray-600">Customer Rating</div>
          </div>
        </div>
      </div>
    </div>
  );
}
