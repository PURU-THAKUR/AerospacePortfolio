interface ComingSoonProps {
  onBackToServices: () => void;
}

export default function ComingSoon({ onBackToServices }: ComingSoonProps) {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center">
        <div className="text-8xl mb-8">🚧</div>
        <h2 className="text-4xl font-bold text-gray-900 mb-4">Feature Coming Soon</h2>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          This service is currently under development. We're working hard to bring you the best experience. 
          Please check back later!
        </p>
        
        <div className="space-y-4">
          <div className="flex items-center justify-center space-x-8 text-gray-500">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
              <span>In Development</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
              <span>Testing Phase</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-gray-300 rounded-full mr-2"></div>
              <span>Launch Ready</span>
            </div>
          </div>
          
          <button
            onClick={onBackToServices}
            className="bg-orange-500 text-white px-8 py-3 rounded-md font-semibold hover:bg-orange-600 transition-colors duration-200"
          >
            Back to Services
          </button>
        </div>
      </div>
    </div>
  );
}
