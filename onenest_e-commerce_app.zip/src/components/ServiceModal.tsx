interface ServiceModalProps {
  service: {
    name: string;
    description: string;
    icon: string;
  };
  onClose: () => void;
  onTryService: () => void;
}

export default function ServiceModal({ service, onClose, onTryService }: ServiceModalProps) {
  const getServiceEmoji = (serviceName: string) => {
    switch (serviceName) {
      case "Food Delivery": return "🍽️";
      case "Medical Help": return "🏥";
      case "Emergency Services": return "🚨";
      case "Online Shopping": return "🛒";
      case "Cab Booking": return "🚕";
      case "Grocery Delivery": return "🛍️";
      case "Travel Booking": return "🚆";
      case "Payments": return "💳";
      default: return "🔧";
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-md mx-4 text-center">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold text-gray-900">Service Details</h3>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-3xl font-light"
          >
            ×
          </button>
        </div>
        
        <div className="mb-6">
          <div className="text-6xl mb-4">{getServiceEmoji(service.name)}</div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">{service.name}</h2>
          <p className="text-gray-600 leading-relaxed">{service.description}</p>
        </div>
        
        <div className="space-y-3">
          <button
            onClick={onTryService}
            className="w-full bg-orange-500 text-white py-3 rounded-md font-semibold hover:bg-orange-600 transition-colors duration-200"
          >
            Try Service
          </button>
          <button
            onClick={onClose}
            className="w-full bg-gray-100 text-gray-700 py-3 rounded-md font-semibold hover:bg-gray-200 transition-colors duration-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
