import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState, useEffect } from "react";
import { toast } from "sonner";

interface HomeProps {
  onServiceClick: (service: any) => void;
}

export default function Home({ onServiceClick }: HomeProps) {
  const services = useQuery(api.services.list) || [];
  const products = useQuery(api.products.list, {}) || [];
  const addToCart = useMutation(api.cart.add);
  const seedData = useMutation(api.seed.seedData);

  const [isSeeded, setIsSeeded] = useState(false);

  useEffect(() => {
    // Seed data if no products exist
    if (products.length === 0 && services.length === 0 && !isSeeded) {
      seedData().then(() => {
        setIsSeeded(true);
        toast.success("Welcome to OneNest! Sample data loaded.");
      }).catch((error) => {
        console.error("Failed to seed data:", error);
      });
    }
  }, [products.length, services.length, seedData, isSeeded]);

  const handleAddToCart = async (productId: string) => {
    try {
      await addToCart({ productId: productId as any, quantity: 1 });
      toast.success("Added to cart!");
    } catch (error) {
      toast.error("Please login to add items to cart");
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Services Section */}
      <section className="mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">OneNest Services</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {services.map((service) => (
            <div
              key={service._id}
              onClick={() => onServiceClick(service)}
              className="bg-white rounded-lg shadow-md p-6 text-center cursor-pointer hover:shadow-lg transition-shadow duration-200 hover:scale-105 transform"
            >
              <div className="text-4xl mb-4 text-orange-500">
                {service.name === "Food Delivery" && "🍽️"}
                {service.name === "Medical Help" && "🏥"}
                {service.name === "Emergency Services" && "🚨"}
                {service.name === "Online Shopping" && "🛒"}
                {service.name === "Cab Booking" && "🚕"}
                {service.name === "Grocery Delivery" && "🛍️"}
                {service.name === "Travel Booking" && "🚆"}
                {service.name === "Payments" && "💳"}
              </div>
              <h3 className="font-semibold text-gray-900">{service.name}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products Section */}
      <section>
        <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.slice(0, 6).map((product) => (
            <div key={product._id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-200">
              <img
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">{product.description}</p>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl font-bold text-orange-500">₹{product.price.toLocaleString()}</span>
                  <div className="flex items-center">
                    <span className="text-yellow-400 mr-1">⭐</span>
                    <span className="text-sm text-gray-600">{product.rating} ({product.reviews})</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Stock: {product.stock}</span>
                  <button
                    onClick={() => handleAddToCart(product._id)}
                    disabled={product.stock === 0}
                    className="bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors duration-200"
                  >
                    {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
